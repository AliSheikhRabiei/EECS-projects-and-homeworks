// user/meter.c
#include "kernel/types.h"
#include "user/user.h"

int main(int argc, char *argv[]) {
  int dur = (argc > 1) ? atoi(argv[1]) : 300;   // duration in ticks (~3s if 100 ticks/s)
  volatile unsigned long work = 0;
  unsigned long iters = 0;

  int me = getpid();
  int pr = getpriority(me);
  int start = uptime();

  while (uptime() - start < dur) {
    // do some CPU work
    for (int i = 0; i < 1000; i++) work += i;
    iters++;
  }

  printf("meter pid=%d pr=%d dur=%d ticks  iters=%d\n", me, pr, dur, (int)iters);
  exit(0);
}
