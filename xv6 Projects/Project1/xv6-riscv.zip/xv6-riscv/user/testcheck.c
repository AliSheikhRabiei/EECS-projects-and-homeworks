// user/testcheck.c
#include "kernel/types.h"
#include "user/user.h"
#include "procinfo.h"

static int percent(int part, int total) {
  if (total <= 0) return 0;
  return (part * 100 + total/2) / total;
}

int main(int argc, char *argv[]) {
  if (argc < 3 || argc > 5) {
    printf("usage: testcheck <pid1> <pid2> [samples=500] [interval_ticks=1]\n");
    exit(1);
  }

  int pid1 = atoi(argv[1]);
  int pid2 = atoi(argv[2]);
  int S= (argc >= 4) ? atoi(argv[3]) : 500;
  int dt= (argc == 5) ? atoi(argv[4]) : 1;

  int run1=0, run2=0, runn1=0, runn2=0, seen1=0, seen2=0;

  enum { CAP = 64 };
  struct procinfo buf[CAP];

  for (int s = 0; s < S; s++) {
    int n = getprocs(buf, CAP);
    for (int i = 0; i < n; i++) {
      if (buf[i].pid == pid1) {
        seen1++;
        if (buf[i].state == 3) run1++;   // RUNNING
        if (buf[i].state == 2) runn1++;  // RUNNABLE
      } else if (buf[i].pid == pid2) {
        seen2++;
        if (buf[i].state == 3) run2++;
        if (buf[i].state == 2) runn2++;
      }
    }
    pause(dt);
  }

  if (seen1==0 || seen2==0) {
    printf("testcheck: one of the PIDs not observed (pid1 seen=%d, pid2 seen=%d)\n", seen1, seen2);
    exit(1);
  }

  printf("Samples=%d interval=%d ticks\n", S, dt);
  printf("PID %d  RUNNING=%d (%d%%)  RUNNABLE=%d (%d%%)\n",
         pid1, run1, percent(run1, seen1), runn1, percent(runn1, seen1));
  printf("PID %d  RUNNING=%d (%d%%)  RUNNABLE=%d (%d%%)\n",
         pid2, run2, percent(run2, seen2), runn2, percent(runn2, seen2));
  exit(0);
}
