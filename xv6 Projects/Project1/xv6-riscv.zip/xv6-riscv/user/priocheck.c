#include "kernel/types.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
  if (argc != 3) {
    printf("usage: priowatch <pid> <samples>\n");
    exit(1);
  }
  int pid = atoi(argv[1]);
  int samples = atoi(argv[2]);

  for (int i = 0; i < samples; i++) {
    printf("t=%d prio=%d\n", uptime(), getpriority(pid));
    // wait roughly 1 tick between prints
    int start = uptime();
    while (uptime() == start) ;
  }
  exit(0);
}
