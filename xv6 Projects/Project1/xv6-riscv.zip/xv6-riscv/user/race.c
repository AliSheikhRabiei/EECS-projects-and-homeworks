// user/race.c
#include "kernel/types.h"
#include "user/user.h"

static void run_worker(int dur_ticks, int prio, int outfd) {
  setpriority(getpid(), prio);
  volatile unsigned long work = 0;
  unsigned long iters = 0;
  int start = uptime();
  while (uptime() - start < dur_ticks) {
    for (int i = 0; i < 1000; i++) work += i;
    iters++;
  }
  // send iters back to parent as a 32-bit number
  int n = (int)iters;
  write(outfd, &n, sizeof(n));
  exit(0);
}

int main(int argc, char *argv[]) {
  if (argc != 4) {
    printf("usage: race <dur_ticks> <prioA> <prioB>\n");
    exit(1);
  }
  int dur = atoi(argv[1]);
  int pA = atoi(argv[2]);
  int pB = atoi(argv[3]);

  int pa[2], pb[2];
  pipe(pa); pipe(pb);

  int pidA = fork();
  if (pidA == 0) { close(pa[0]); close(pb[0]); close(pb[1]); run_worker(dur, pA, pa[1]); }

  int pidB = fork();
  if (pidB == 0) { close(pb[0]); close(pa[0]); close(pa[1]); run_worker(dur, pB, pb[1]); }

  // parent
  close(pa[1]); close(pb[1]);

  int aIters = 0, bIters = 0;
  read(pa[0], &aIters, sizeof(aIters));
  read(pb[0], &bIters, sizeof(bIters));
  wait(0); wait(0);

  printf("race dur=%d ticks  A(pid=%d pr=%d) iters=%d   B(pid=%d pr=%d) iters=%d\n",
         dur, pidA, pA, aIters, pidB, pB, bIters);
  exit(0);
}
