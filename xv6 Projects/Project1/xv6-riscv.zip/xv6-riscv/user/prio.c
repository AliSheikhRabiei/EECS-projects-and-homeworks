//user/prio.c
#include "kernel/types.h"
#include "user/user.h"

int main(int argc, char *argv[]) {
  if (argc < 2) {
    printf("usage: prio get <pid> | prio set <pid> <prio>\n");
    exit(1);
  }
  if (strcmp(argv[1], "get") == 0 && argc == 3) {
    int pid = atoi(argv[2]);
    printf("getpriority(%d) = %d\n", pid, getpriority(pid));
    exit(0);
  }
  if (strcmp(argv[1], "set") == 0 && argc == 4) {
    int pid = atoi(argv[2]);
    int pr  = atoi(argv[3]);
    printf("setpriority(%d,%d) -> %d\n", pid, pr, setpriority(pid, pr));
    exit(0);
  }
  printf("usage: prio get <pid> | prio set <pid> <prio>\n");
  exit(1);
}
