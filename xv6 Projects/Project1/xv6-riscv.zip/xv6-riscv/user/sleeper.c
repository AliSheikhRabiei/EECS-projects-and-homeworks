// user/hold.c
#include "kernel/types.h"
#include "user/user.h"

int main(int argc, char *argv[]) {
	printf("sleeping!");
	int ticks = 100;         
	for (;;) {
		pause(ticks);         
	}
}
