#include "kernel/types.h"
#include "user/user.h"
#include "procinfo.h"

/*
int main(void)
{
  enum { CAP = 64 };                 
  struct procinfo a[CAP];

  int n = getprocs(a, CAP);
  if (n < 0) {
    printf("ps: getprocs failed\n");
    exit(1);
  }

  printf("PID PPID STATE SZ NAME\n");
  for (int i = 0; i < n; i++) {
    // xv6 printf supports: %d, %x, %p, %s (no width, no %u)
    printf("%d %d %d %d %s\n",
           a[i].pid, a[i].ppid, a[i].state, (int)a[i].sz, a[i].name);
  }
  exit(0);
}*/

static const char *stname(int s) {
  switch (s) {
    case 0: return "UNUSED";
    case 1: return "SLEEP";
    case 2: return "RUNNABLE";
    case 3: return "RUNNING";
    case 4: return "ZOMBIE";
    default: return "?";
  }
}

int main(void) {
  int CAP = 64;
  struct procinfo *a = (struct procinfo*) malloc(CAP * sizeof(struct procinfo));
  if (a == 0) {
    printf("ps: malloc failed\n");
    exit(1);
  }

  int n = getprocs(a, CAP);
  if (n < 0) {
    printf("ps: getprocs failed\n");
    free(a);
    exit(1);
  }

  printf("PID PPID STATE SZ NAME\n");
  for (int i = 0; i < n; i++) {
    printf("%d %d %s %d %s\n",
           a[i].pid, a[i].ppid, stname(a[i].state), (int)a[i].sz, a[i].name);
  }

  free(a);
  exit(0);
}
