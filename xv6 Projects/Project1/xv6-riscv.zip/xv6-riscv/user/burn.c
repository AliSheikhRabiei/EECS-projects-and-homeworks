// user/burn.c
#include "kernel/types.h"
#include "user/user.h"

int main(int argc, char *argv[]) {
  int id = getpid();
  volatile unsigned long s = 0;
  for (s=0;;s++) {
    for (unsigned long i = 0; ; i++) {s += i;}
    if((s%10000)==0){printf("burn pid=%d alive for %lu rounds\n", id, s);}
    pause(1);
  }
}
