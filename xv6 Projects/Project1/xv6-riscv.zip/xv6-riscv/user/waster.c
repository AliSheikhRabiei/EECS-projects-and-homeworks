#include "kernel/types.h"
#include "user/user.h"

int main(int argc, char *argv[]) {
  unsigned long x = 0;
  printf("doing something!");
  for (;;)  {
    for (unsigned long i = 0; i < 1000000UL; i++) x += i;  
    pause(10);                                              
  }
}
