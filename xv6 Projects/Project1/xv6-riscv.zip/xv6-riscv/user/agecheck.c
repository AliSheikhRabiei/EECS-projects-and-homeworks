#include "kernel/types.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
  if (argc < 4) {
    printf("usage: agetest <pid> <samples> <dt_ticks>\n");
    exit(1);
  }
  int pid = atoi(argv[1]);
  int S   = atoi(argv[2]);
  int dt  = atoi(argv[3]);

  for (int i = 0; i < S; i++) {
    int pr = getpriority(pid);
    printf("t=%d prio=%d\n", i, pr);
    pause(dt);   
  }
  exit(0);
}
