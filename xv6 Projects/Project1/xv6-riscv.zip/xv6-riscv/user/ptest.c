#include "kernel/types.h"
#include "user/user.h"
#include "procinfo.h"

int main(void) {
  struct procinfo buf[4];

  int n = getprocs(buf, -5);
  printf("max<0 %d expect -1\n", n);

  n = getprocs(buf, 0);
  printf("max=0, %d expect 0\n", n);

  n = getprocs((struct procinfo*)0, 2);
  printf("NULL ptr= %d expect -1\n", n);

  n = getprocs(buf, 2);
  printf("normal= %d expect >=1\n", n);
  for (int i = 0; i < n; i++)
    printf("%d %d %d %d %s\n", buf[i].pid, buf[i].ppid, buf[i].state, (int)buf[i].sz, buf[i].name);

  exit(0);
}
