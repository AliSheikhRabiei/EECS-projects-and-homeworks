#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "vm.h"
#include "proc.h"
#include "procinfo.h"

extern struct proc proc[NPROC];

// setpriority, 0 on success, -1 on error
uint64
sys_setpriority(void)
{
  int pid, prio;

  // fetch arguments 
  argint(0, &pid);
  argint(1, &prio);

  // validate priority range
  if (prio < PRIO_MIN || prio > PRIO_MAX)
    return (uint64)-1;

  // scan process table
  for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    acquire(&p->lock);
    if (p->state != UNUSED && p->pid == pid) {
      p->priority = prio;
      p->base_priority = prio;     
      p->wait_ticks= 0;       
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
  }
  return (uint64)-1;  // pid not found
}

// get current priority, or -1 if not found
uint64
sys_getpriority(void)
{
  int pid;
  argint(0, &pid);

  for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    acquire(&p->lock);
    if (p->state != UNUSED && p->pid == pid) {
      int pr = p->priority;
      release(&p->lock);
      return (uint64)pr;
    }
    release(&p->lock);
  }
  return (uint64)-1;  // pid not found
}

uint64
sys_getprocs(void)
{
  uint64 uptr;  
  int max;

  argaddr(0, &uptr);
  argint(1, &max);

  if (uptr == 0 || max < 0)
    return (uint64)-1;

  if (max == 0)
    return 0;

  int count = 0;

  for (struct proc *p = proc; p < &proc[NPROC] && count < max; p++) {
    acquire(&p->lock);
    if (p->state != UNUSED) {
      struct procinfo info;
      info.pid   = p->pid;
      info.ppid  = p->parent ? p->parent->pid : 0;
      info.state = p->state;
      info.sz    = p->sz;
      safestrcpy(info.name, p->name, sizeof(info.name));

      if (copyout(myproc()->pagetable,
                  uptr + (uint64)count * sizeof(info),
                  (char*)&info, sizeof(info)) < 0) {
        release(&p->lock);
        return (uint64)-1;          
      }
      count++;
    }
    release(&p->lock);
  }
  return (uint64)count;
}

uint64
sys_getcourseno(void)
{
    return 3221;
}

uint64
sys_exit(void)
{
  int n;
  argint(0, &n);
  kexit(n);
  return 0;  // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return kfork();
}

uint64
sys_wait(void)
{
  uint64 p;
  argaddr(0, &p);
  return kwait(p);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
  argint(1, &t);
  addr = myproc()->sz;

  if(t == SBRK_EAGER || n < 0) {
    if(growproc(n) < 0) {
      return -1;
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if(addr + n < addr)
      return -1;
    if(addr + n > TRAPFRAME)
      return -1;
    myproc()->sz += n;
  }
  return addr;
}

uint64
sys_pause(void)
{
  int n;
  uint ticks0;

  argint(0, &n);
  if(n < 0)
    n = 0;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kkill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}
