struct procinfo {
    int pid;           // Process ID
    int ppid;          // Parent process ID
    int state;         // Process state (UNUSED, EMBRYO, SLEEPING, RUNNABLE, RUNNING, ZOMBIE)
    uint sz;           // Size of process memory (bytes)
    char name[16];     // Process name
};
